# materialized_jekyll_theme

As the title suggests, this repo is for a [jekyll theme](http://jekyllrb.com) that's based on Material design. It uses [Matarialize.css](http://materializecss.com) to implement its material goodness.

If you want to see the theme in action, check out [our website](http://www.enterthecrucible.co). Its is based off of this theme.
